ms.ContentId: 2349056D-A75D-4CC6-8A6B-AF14379604F8

<!-- BEGINSECTION class="alert alert-warning" id="version-statement" -->

This API in preview. [Learn more](http://www.visualstudio.com/integrate/support/support-faq-vsi#API_Q1)

<!-- ENDSECTION --> 